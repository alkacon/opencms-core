<%@ tag pageEncoding="UTF-8"
    display-name="privacy-policy-settings"
    body-content="empty"
    trimDirectiveWhitespaces="true"
    description="Displays the 'privacy policy' settings." %>


<%@ attribute name="cssWrapper" type="java.lang.String" required="true"
    description="The CSS wrapper class to use." %>

<%@ attribute name="policyFile" type="java.lang.String" required="false"
    description="The privacy policy configuration file." %>

<%@ attribute name="contentPropertiesSearch" type="java.util.Map" required="false"
    description="The properties read from the URI resource with search." %>


<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="cms" uri="http://www.opencms.org/taglib/cms"%>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions"%>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt"%>
<%@ taglib prefix="m" tagdir="/WEB-INF/tags/mercury" %>


<fmt:setLocale value="${cms.locale}" />
<cms:bundle basename="alkacon.mercury.template.messages">

<m:privacy-policy-vars locatePolicyFile="${true}" setStatisticalVars="${true}" contentPropertiesSearch="${contentPropertiesSearch}">

<m:nl />
<div class="element type-privacy-policy pp-settings pivot ${cssWrapper}" id="privacy-policy-settings"><%----%>
<m:nl />

<div class="pp-toggle pp-toggle-technical animated"><%----%>
    <input id="cookies-accepted-technical" type="checkbox" class="toggle-check" checked disabled><%----%>
    <label for="cookies-accepted-technical" class="toggle-label" title="<fmt:message key='msg.page.privacypolicy.toggle.label.technical' />"><%----%>
        <span class="toggle-box"><%----%>
            <span class="toggle-inner" <%--
            --%>data-checked="<fmt:message key="msg.page.privacypolicy.toggle.active" />" <%--
            --%>data-unchecked="<fmt:message key="msg.page.privacypolicy.toggle.inactive" />"><%----%>
            </span><%----%>
            <span class="toggle-slider"></span><%----%>
        </span><%----%>
    </label><%----%>
    <div class="toggle-text" aria-hidden="true"><fmt:message key="msg.page.privacypolicy.toggle.label.technical" /></div><%----%>
</div><%----%>
<m:nl />

<div class="pp-toggle pp-toggle-external animated"><%----%>
    <input id="cookies-accepted-external" type="checkbox" class="toggle-check optional"><%----%>
    <label for="cookies-accepted-external" class="toggle-label" title="<fmt:message key='msg.page.privacypolicy.toggle.label.external' />"><%----%>
        <span class="toggle-box"><%----%>
            <span class="toggle-inner" <%--
            --%>data-checked="<fmt:message key="msg.page.privacypolicy.toggle.active" />" <%--
            --%>data-unchecked="<fmt:message key="msg.page.privacypolicy.toggle.inactive" />"><%----%>
            </span><%----%>
            <span class="toggle-slider"></span><%----%>
        </span><%----%>
    </label><%----%>
    <div class="toggle-text" aria-hidden="true"><fmt:message key="msg.page.privacypolicy.toggle.label.external" /></div><%----%>
</div><%----%>
<m:nl />

<c:if test="${showUseStatistical}">
    <div class="pp-toggle pp-toggle-statistical animated"><%----%>
        <input id="cookies-accepted-statistical" type="checkbox" class="toggle-check optional"><%----%>
        <label for="cookies-accepted-statistical" class="toggle-label" title="<fmt:message key='msg.page.privacypolicy.toggle.label.statistical' />"><%----%>
            <span class="toggle-box"><%----%>
                <span class="toggle-inner" <%--
                --%>data-checked="<fmt:message key="msg.page.privacypolicy.toggle.active" />" <%--
                --%>data-unchecked="<fmt:message key="msg.page.privacypolicy.toggle.inactive" />"><%----%>
                </span><%----%>
                <span class="toggle-slider"></span><%----%>
            </span><%----%>
        </label><%----%>
       <div class="toggle-text" aria-hidden="true"><fmt:message key="msg.page.privacypolicy.toggle.label.statistical" /></div><%----%>
    </div><%----%>
    <m:nl />
</c:if>

<c:if test="${not empty contentPropertiesSearch and not empty policyFile and policyFile ne 'none'}">

    <c:if test="${showMatomo and useMatomoJst}">

        <c:if test="${not fn:startsWith(policyFile, '/')}">
            <c:set var="subSitePolicy" value="${cms.subSitePath.concat('.content/').concat(policyFile)}" />
            <c:set var="sitePolicy" value="${'/.content/'.concat(policyFile)}" />
            <c:set var="policyFile" value="${cms.vfs.exists[subSitePolicy] ? subSitePolicy : sitePolicy}" />
        </c:if>
        <c:set var="policyRes" value="${cms.vfs.readXml[policyFile]}" />

        <c:choose>
            <c:when test="${not cms.isOnlineProject}">
                <div class="pp-element not-online"><%----%>
                    <fmt:message key="msg.page.privacypolicy.Matomo.notonline" />
                </div><%----%>
            </c:when>
            <c:otherwise>
                <cms:jsonobject var="matomoJst">
                    <fmt:message key="msg.page.privacypolicy.Matomo.JsTrackingText" var="JsTrackingText" />
                    <cms:jsonvalue key="jsttext">${policyRes.value.MatomoPolicy.value.JsTrackingText.isSet ? policyRes.value.MatomoPolicy.value.JsTrackingText : JsTrackingText}</cms:jsonvalue>
                    <fmt:message key="msg.page.privacypolicy.Matomo.JsTrackingOn" var="JsTrackingOn" />
                    <cms:jsonvalue key="jston">${policyRes.value.MatomoPolicy.value.JsTrackingOn.isSet ? policyRes.value.MatomoPolicy.value.JsTrackingOn : JsTrackingOn}</cms:jsonvalue>
                    <fmt:message key="msg.page.privacypolicy.Matomo.JsTrackingOff" var="JsTrackingOff" />
                    <cms:jsonvalue key="jstoff">${policyRes.value.MatomoPolicy.value.JsTrackingOff.isSet ? policyRes.value.MatomoPolicy.value.JsTrackingOff : JsTrackingOff}</cms:jsonvalue>
                    <c:if test="${useMatomoDnt}">
                        <fmt:message key="msg.page.privacypolicy.Matomo.DntText" var="DntText" />
                        <cms:jsonvalue key="dnttext">${policyRes.value.MatomoPolicy.value.DntText.isSet ? policyRes.value.MatomoPolicy.value.DntText : DntText}</cms:jsonvalue>
                    </c:if>
                </cms:jsonobject>
                <div id="pp-matomo-jst" class="pp-element" data-jst='${matomoJst.compact}'><%----%>
                    <div class="jst-msg"></div><%----%>
                    <div class="jst-btn"><%----%>
                        <label for="pp-matomo-optout" class="checkbox"><%----%>
                            <input type="checkbox" id="pp-matomo-optout" /><%----%>
                            <i></i><%----%>
                            <span></span><%----%>
                        </label><%----%>
                    </div><%----%>
                </div><%----%>
            </c:otherwise>
        </c:choose>
        <m:nl />

    </c:if>
</c:if>

</div><%----%>
<m:nl />

</m:privacy-policy-vars>

</cms:bundle>