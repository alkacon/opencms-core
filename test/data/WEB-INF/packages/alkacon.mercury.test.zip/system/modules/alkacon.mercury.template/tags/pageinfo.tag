<%@ tag pageEncoding="UTF-8"
    display-name="pageinfo"
    body-content="empty"
    trimDirectiveWhitespaces="true"
    import ="org.opencms.workplace.CmsWorkplace"
    description="Generates a DIV with runtime information that can be used from JavaScipt." %>


<%@ attribute name="contentPropertiesSearch" type="java.util.Map" required="true"
    description="The properties read from the URI resource with search." %>


<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="cms" uri="http://www.opencms.org/taglib/cms"%>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions"%>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt"%>
<%@ taglib prefix="m" tagdir="/WEB-INF/tags/mercury" %>


<%-- Google Maps API key --%>
<c:set var="googleApiKey" value="${not empty cms.getSecretForUri('google.apikey') ? cms.getSecretForUri('google.apikey') : contentPropertiesSearch['google.apikey']}" />

<%-- Google Maps API key for the workplace--%>
<c:set var="googleApiKeyWorkplace" value="${not empty cms.getSecretForUri('google.apikey.workplace') ? cms.getSecretForUri('google.apikey.workplace') : contentPropertiesSearch['google.apikey.workplace']}" />

<%-- Google Analytics ID --%>
<c:set var="googleAnalyticsId" value="${not empty cms.getSecretForUri('google.analytics') ? cms.getSecretForUri('google.analytics') : contentPropertiesSearch['google.analytics']}" />

<%-- OSM API key --%>
<c:set var="osmApiKey" value="${not empty cms.getSecretForUri('osm.apikey') ? cms.getSecretForUri('osm.apikey') : contentPropertiesSearch['osm.apikey']}" />

<%-- OSM style URL --%>
<c:set var="osmStyleUrl" value="${not empty cms.getSecretForUri('osm.styleurl') ? cms.getSecretForUri('osm.styleurl') : contentPropertiesSearch['osm.styleurl']}" />

<%-- Piwik --%>
<c:set var="piwikUrl" value="${not empty cms.getSecretForUri('piwik.url') ? cms.getSecretForUri('piwik.url') : contentPropertiesSearch['piwik.url']}" />
<c:set var="piwikId" value="${not empty cms.getSecretForUri('piwik.id') ? cms.getSecretForUri('piwik.id') : contentPropertiesSearch['piwik.id']}" />
<c:set var="hidePiwik" value="${empty piwikUrl or piwikUrl eq 'none' or empty piwikId or piwikId eq 'none'}" />

<c:if test="${not hidePiwik}">
    <c:set var="piwikAddData" value="${not empty cms.getSecretForUri('piwik.data') ? cms.getSecretForUri('piwik.data') : contentPropertiesSearch['piwik.data']}" />
    <c:set var="piwikData">data-piwik='{<%--
        --%><c:if test="${not empty piwikId}">"id":"${piwikId}",</c:if><%--
        --%><c:if test="${not empty piwikAddData}">${piwikAddData},</c:if><%--
        --%>"url":"${piwikUrl}"}' <%--
--%></c:set>
</c:if>

<%-- Matomo --%>
<c:set var="matomoUrl" value="${not empty cms.getSecretForUri('matomo.url') ? cms.getSecretForUri('matomo.url') : contentPropertiesSearch['matomo.url']}" />
<c:set var="matomoId" value="${not empty cms.getSecretForUri('matomo.id') ? cms.getSecretForUri('matomo.id') : contentPropertiesSearch['matomo.id']}" />
<c:set var="hideMatomo" value="${empty matomoUrl or matomoUrl eq 'none' or empty matomoId or matomoId eq 'none'}" />

<c:if test="${not hideMatomo}">
    <c:set var="matomoJst" value="${not empty cms.getSecretForUri('matomo.jst') ? cms.getSecretForUri('matomo.jst') : contentPropertiesSearch['matomo.jst']}" />
    <c:set var="useMatomoJst" value="${not empty matomoJst ? fn:contains(matomoJst, 'true') : false}" />
    <c:set var="useMatomoDnt" value="${not empty matomoJst ? fn:contains(matomoJst, 'dnt') : false}" />
    <c:set var="matomoAddData" value="${contentPropertiesSearch['matomo.data']}" />
    <c:set var="matomoData">data-matomo='{<%--
        --%><c:if test="${not empty matomoId}">"id":"${matomoId}",</c:if><%--
        --%>"jst":${useMatomoJst},<%--
        --%>"dnt":${useMatomoDnt},<%--
        --%><c:if test="${not empty matomoAddData}">${matomoAddData},</c:if><%--
        --%>"url":"${matomoUrl}"}' <%--
--%></c:set>
</c:if>

<%-- OpenCms project --%>
<c:set var ="project" value="${cms.isOnlineProject ? 'online' : 'offline'}" />

<%-- Icon configuration --%>
<c:if test="${fn:contains(cms.sitemapConfig.attribute['mercury.iconFont.config'].toString, 'Selection')}">
    <c:set var="iconConfig"><cms:link>/system/modules/alkacon.mercury.theme/icons/fa/at.svg</cms:link></c:set>
    <c:set var="iconConfigBase64"><m:obfuscate text="${iconConfig}" type="base64"/></c:set>
    <c:if test="${fn:contains(cms.sitemapConfig.attribute['mercury.iconFont.config'].toString, 'awesome')}">
        <c:set var="fullIcons"><m:link-resource resource='/system/modules/alkacon.mercury.theme/css/awesome-full.min.css'/></c:set>
        <c:set var="fullIconsBase64"><m:obfuscate text="${fullIcons}" type="base64"/></c:set>
    </c:if>
</c:if>

<m:nl/>
<oc-div id="template-info" data-info='{<%--
    --%><c:if test="${not empty googleApiKey}">"googleApiKey":"${googleApiKey}",</c:if><%--
    --%><c:if test="${not empty googleAnalyticsId}">"googleAnalyticsId":"${googleAnalyticsId}",</c:if><%--
    --%><c:if test="${not empty osmApiKey}">"osmApiKey":"${osmApiKey}",</c:if><%--
    --%><c:if test="${not empty osmApiKey}">"osmSpriteUrl":"<%= CmsWorkplace.getStaticResourceUri("/osm/sprite") %>",</c:if><%--
    --%><c:if test="${not empty osmApiKey and not empty osmStyleUrl}">"osmStyleUrl":"${osmStyleUrl}",</c:if><%--
    --%><c:if test="${not empty googleApiKeyWorkplace}">"googleApiKeyWorkplace":"${googleApiKeyWorkplace}",</c:if><%--
    --%><c:if test="${not empty iconConfigBase64}">"iconConfig":"${iconConfigBase64}",</c:if><%--
    --%><c:if test="${not empty fullIconsBase64}">"fullIcons":"${fullIconsBase64}",</c:if><%--
    --%>"editMode":"${cms.isEditMode}",<%--
    --%>"project":"${project}",<%--
    --%>"context":"<cms:link>/</cms:link>",<%--
    --%>"locale":"${cms.locale}"<%--
--%>}'<%--
--%>${empty matomoData ? '' : ' '.concat(matomoData)}<%--
--%>${empty piwikData ? '' : ' '.concat(piwikData)}<%--
--%>><%----%>
<m:nl/>

<oc-div id="template-grid-info"></oc-div><%----%>

<m:template-marker name="Mercury" showGrid="${true}" />

</oc-div><%----%>
<m:nl/>

<div id="topcontrol" tabindex="0"></div>

