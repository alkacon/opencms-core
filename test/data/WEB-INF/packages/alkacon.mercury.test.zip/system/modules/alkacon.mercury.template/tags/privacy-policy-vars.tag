<%@ tag pageEncoding="UTF-8"
    display-name="privacy-policy-vars"
    body-content="scriptless"
    trimDirectiveWhitespaces="true"
    description="Reads the policy content and sets a series of variables for quick access." %>


<%@ attribute name="locatePolicyFile" type="java.lang.Boolean" required="false"
    description="If 'true', the policy resource file is located. The location is written to the variable 'policyFile'." %>

<%@ attribute name="setPolicyLinks" type="java.lang.Boolean" required="false"
    description="If 'true', then the links to the imprint page etc. are read from the policy file and stored in variables." %>

<%@ attribute name="setStatisticalVars" type="java.lang.Boolean" required="false"
    description="If 'true', then the properties for statistics are read and the results are stored in variables." %>

<%@ attribute name="contentPropertiesSearch" type="java.util.Map" required="false"
    description="The properties read from the content page URI resource with search. If not set  and 'locatePolicyFile' is 'true', this will be read based on the value of 'cms.requestContext.uri'." %>

<%@ attribute name="content" type="org.opencms.jsp.util.CmsJspContentAccessBean" required="false"
    description="The privacy policy configuration content access bean. If not set and 'setPolicyLinks' is 'true', then 'cms.requestContext.uri' will be used to locate the policy content file first." %>


<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="cms" uri="http://www.opencms.org/taglib/cms"%>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions"%>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt"%>
<%@ taglib prefix="m" tagdir="/WEB-INF/tags/mercury" %>


<%@ variable name-given="policyFile"                declare="true" %>
<%@ variable name-given="policyBaseUri"             declare="true" %>
<%@ variable name-given="policyContent"             declare="true" %>

<%@ variable name-given="policyLinkImprint"         declare="true" %>
<%@ variable name-given="policyLinkPolicy"          declare="true" %>
<%@ variable name-given="policyLinkLegal"           declare="true" %>

<%@ variable name-given="policyTextImprint"         declare="true" %>
<%@ variable name-given="policyTextPolicy"          declare="true" %>
<%@ variable name-given="policyTextLegal"           declare="true" %>

<%@ variable name-given="hasPolicyLinks"            declare="true" %>

<%@ variable name-given="showPolicyLinkSettings"    declare="true" %>
<%@ variable name-given="policyLinkSettings"        declare="true" %>
<%@ variable name-given="policyLinkSettingsText"    declare="true" %>

<%@ variable name-given="showGoogle"            declare="true" %>
<%@ variable name-given="showMatomo"            declare="true" %>
<%@ variable name-given="showPiwik"             declare="true" %>
<%@ variable name-given="showUseStatistical"    declare="true" %>
<%@ variable name-given="useMatomoDnt"          declare="true" %>
<%@ variable name-given="useMatomoJst"          declare="true" %>

<%@ variable name-given="policyTest"                declare="true" %>


<c:set var="policyBaseUri" value="${cms.requestContext.uri}" />
<c:set var="policyContent" value="${content}" />

<c:if test="${locatePolicyFile or (setPolicyLinks and empty policyContent)}">

    <c:if test="${empty contentPropertiesSearch}">
        <%-- Do not use contentUri for properties, always read from the request context URI. This is identical to the m:content-properties.tag --%>
        <c:set var="contentPropertiesSearch" value="${cms.vfs.readPropertiesSearch[policyBaseUri]}" />
    </c:if>

    <c:set var="policyFile" value="${empty contentPropertiesSearch['mercury.privacy.policy'] ? null : contentPropertiesSearch['mercury.privacy.policy']}" />
    <c:set var="policyFile" value="${policyFile eq 'none' ? null : policyFile}" />

    <c:if test="${not empty policyFile}">
        <c:if test="${not fn:startsWith(policyFile, '/')}">
            <c:set var="subSitePolicy" value="${cms.subSitePath.concat('.content/').concat(policyFile)}" />
            <c:set var="sitePolicy" value="${'/.content/'.concat(policyFile)}" />
            <c:set var="policyFile" value="${cms.vfs.exists[subSitePolicy] ? subSitePolicy : sitePolicy}" />
        </c:if>
        <c:if test="${setPolicyLinks and empty policyContent}">
            <c:set var="policyContent" value="${cms.vfs.readXml[policyFile]}" />
        </c:if>
    </c:if>

</c:if>

<c:if test="${setPolicyLinks}">

    <fmt:setLocale value="${cms.locale}" />
    <cms:bundle basename="alkacon.mercury.template.messages">

    <c:set var="value" value="${policyContent.value}" />

    <c:set var="policyLinkImprint" value="${value.LinkImprint.value.URI.toLink}" />
    <c:if test="${empty policyLinkImprint}">
        <c:set var="policyLinkImprint" value="${cms.functionDetailPageExact['Imprint']}" />
        <c:if test="${not fn:startsWith(policyLinkImprint, '/') and not fn:startsWith(policyLinkImprint, 'http')}">
            <c:set var="policyLinkImprint" value="${null}" />
        </c:if>
    </c:if>
    <c:if test="${not empty policyLinkImprint}">
        <c:set var="policyLinkImprint">
            <m:link-opencms targetLink="${policyLinkImprint}" />
        </c:set>
    </c:if>
    <c:if test="${not empty policyLinkImprint}">
        <c:set var="hasPolicyLinks" value="${true}" />
        <c:set var="policyTextImprint" value="${value.LinkImprint.value.Text.toString}" />
        <c:if test="${empty policyTextImprint}">
            <fmt:message var="policyTextImprint" key="msg.page.privacypolicy.link.imprint" />
        </c:if>
    </c:if>

    <c:set var="policyLinkPolicy" value="${value.LinkPolicy.value.URI.toLink}" />
    <c:if test="${empty policyLinkPolicy}">
        <c:set var="policyLinkPolicy" value="${cms.functionDetailPageExact['Datenschutz']}" />
        <c:if test="${not fn:startsWith(policyLinkPolicy, '/') and not fn:startsWith(policyLinkPolicy, 'http')}">
            <c:set var="policyLinkPolicy" value="${null}" />
        </c:if>
    </c:if>
    <c:if test="${not empty policyLinkPolicy}">
        <c:set var="policyLinkPolicy">
            <m:link-opencms targetLink="${policyLinkPolicy}" />
        </c:set>
    </c:if>
    <c:if test="${not empty policyLinkPolicy}">
        <c:set var="hasPolicyLinks" value="${true}" />
        <c:set var="policyTextPolicy" value="${value.LinkPolicy.value.Text.toString}" />
        <c:if test="${empty policyTextPolicy}">
            <fmt:message var="policyTextPolicy" key="msg.page.privacypolicy.link.policy" />
        </c:if>
    </c:if>

    <c:set var="policyLinkLegal" value="${value.LinkLegal.value.URI.toLink}" />
    <c:if test="${empty policyLinkLegal}">
        <c:set var="policyLinkLegal" value="${cms.functionDetailPageExact['Rechtliche Hinweise']}" />
        <c:if test="${not fn:startsWith(policyLinkLegal, '/') and not fn:startsWith(policyLinkLegal, 'http')}">
            <c:set var="policyLinkLegal" value="${null}" />
        </c:if>
    </c:if>
    <c:if test="${not empty policyLinkLegal}">
        <c:set var="policyLinkLegal">
            <m:link-opencms targetLink="${policyLinkLegal}" />
        </c:set>
    </c:if>
    <c:if test="${not empty policyLinkLegal}">
        <c:set var="hasPolicyLinks" value="${true}" />
        <c:set var="policyTextLegal" value="${value.LinkLegal.value.Text.toString}" />
        <c:if test="${empty policyTextLegal}">
            <fmt:message var="policyTextLegal" key="msg.page.privacypolicy.link.legal" />
        </c:if>
    </c:if>

    <c:set var="showPolicyLinkSettings" value="${false}" />
    <c:if test="${value.ShowLinkSettings.useDefault('false').toBoolean and (not empty policyLinkPolicy or not empty value.LinkSettings.value.URI.toLink)}">
        <c:set var="showPolicyLinkSettings" value="${true}" />
        <c:choose>
            <c:when test="${value.LinkSettings.value.URI.isSet}">
                <c:set var="policyLinkSettings">
                    <m:link-opencms targetLink="${value.LinkSettings.value.URI.toLink}" />
                </c:set>
            </c:when>
            <c:otherwise>
                <c:set var="policyLinkSettings" value="${policyLinkPolicy}" />
            </c:otherwise>
        </c:choose>
        <c:if test="${not fn:contains(policyLinkSettings, '#')}">
            <c:set var="policyLinkSettings" value="${policyLinkSettings}#privacy-policy-settings" />
        </c:if>
        <c:set var="policyLinkSettingsText" value="${value.LinkSettings.value.Text.toString}" />
        <c:if test="${empty policyLinkSettingsText}">
            <fmt:message var="policyLinkSettingsText" key="msg.page.privacypolicy.link.policysettings" />
        </c:if>
    </c:if>

    </cms:bundle>

</c:if>

<c:if test="${setStatisticalVars}">

    <c:if test="${empty contentPropertiesSearch}">
        <%-- Do not use contentUri for properties, always read from the request context URI. This is identical to the m:content-properties.tag --%>
        <c:set var="contentPropertiesSearch" value="${cms.vfs.readPropertiesSearch[policyBaseUri]}" />
    </c:if>

    <c:set var="matomoUrl" value="${not empty cms.getSecretForUri('matomo.url') ? cms.getSecretForUri('matomo.url') : contentPropertiesSearch['matomo.url']}" />
    <c:set var="matomoId" value="${not empty cms.getSecretForUri('matomo.id') ? cms.getSecretForUri('matomo.id') : contentPropertiesSearch['matomo.id']}" />
    <c:set var="matomoJst" value="${not empty cms.getSecretForUri('matomo.jst') ? cms.getSecretForUri('matomo.jst') : contentPropertiesSearch['matomo.jst']}" />
    <c:set var="useMatomoJst" value="${not empty matomoJst ? fn:contains(matomoJst, 'true') : false}" />
    <c:set var="useMatomoDnt" value="${not empty matomoJst ? fn:contains(matomoJst, 'dnt') : false}" />
    <c:set var="showMatomo" value="${(not empty matomoUrl and matomoUrl ne 'none') and (not empty matomoId and matomoId ne 'none')}" />

    <c:set var="piwikUrl" value="${not empty cms.getSecretForUri('piwik.url') ? cms.getSecretForUri('piwik.url') : contentPropertiesSearch['piwik.url']}" />
    <c:set var="piwikId" value="${not empty cms.getSecretForUri('piwik.id') ? cms.getSecretForUri('piwik.id') : contentPropertiesSearch['piwik.id']}" />
    <c:set var="showPiwik" value="${(not empty piwikUrl and piwikUrl ne 'none') and (not empty piwikId and piwikId ne 'none')}" />

    <c:set var="googleAnalyticsId" value="${not empty cms.getSecretForUri('google.analytics') ? cms.getSecretForUri('google.analytics') : contentPropertiesSearch['google.analytics']}" />
    <c:set var="showGoogle" value="${not empty googleAnalyticsId and googleAnalyticsId ne 'none'}" />

    <c:set var="showUseStatistical" value="${showMatomo or showPiwik or showGoogle}" />

</c:if>

<jsp:doBody />
